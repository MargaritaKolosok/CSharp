﻿using OpenQA.Selenium;

namespace DockerSeleniumGridTestApplication
{
    public class Base
    {
        public IWebDriver Driver { get; set; }
    }
}
